AdminBro.UserComponents = {}
import Component1 from '../src/blogs/components/upload-image.edit'
AdminBro.UserComponents.Component1 = Component1
import Component2 from '../src/blogs/components/upload-image.list'
AdminBro.UserComponents.Component2 = Component2
import Component3 from '../src/components/dashboard'
AdminBro.UserComponents.Component3 = Component3