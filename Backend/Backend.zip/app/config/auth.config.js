module.exports = {
  secret: "protalent-secret-key",
  email: "abualemayehu16@gmail.com",
  pass:"cnppndcflcyhnctl"
};