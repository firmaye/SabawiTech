const getUser = require("./getUser");
const authJwt = require("./authJwt");

module.exports = {
	getUser,
	authJwt,
};