import React from 'react'

const Edit: React.FC<BasePropertyProps> = (props) => {
  return (
   <h1>Admin Dashboard</h1>
  )
}

export default Edit